package sistemagestionfx;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class FormularioCliente extends VBox {

    public FormularioCliente(StackPane parent) {

        this.getStylesheets().add(
                getClass().getResource("style.css").toExternalForm()
        );

        this.getStyleClass().add("form-container");

        this.setSpacing(15);

        this.setPadding(new Insets(30));

        this.setAlignment(Pos.CENTER);

        this.setMaxSize(400, 350);

        Label titulo = new Label("GESTIÓN DE CLIENTES");

        titulo.setStyle(
                "-fx-font-size: 20px; -fx-font-weight: bold;"
        );

        GridPane grid = new GridPane();

        grid.setHgap(10);

        grid.setVgap(15);

        grid.setAlignment(Pos.CENTER);

        // ID CLIENTE
        grid.add(new Label("ID Cliente:"), 0, 0);

        TextField txtId = new TextField();

        grid.add(txtId, 1, 0);

        // NOMBRE
        grid.add(new Label("Nombre:"), 0, 1);

        TextField txtNombre = new TextField();

        grid.add(txtNombre, 1, 1);

        // TELEFONO
        grid.add(new Label("Teléfono:"), 0, 2);

        TextField txtTelefono = new TextField();

        grid.add(txtTelefono, 1, 2);

        // BOTONES
        HBox hbButtons = new HBox(15);

        hbButtons.setAlignment(Pos.CENTER);

        Button btnGuardar = new Button("Guardar");

        btnGuardar.getStyleClass().add("btn-entrar");

        btnGuardar.setPrefWidth(100);

        btnGuardar.setOnAction(e -> {

            Alert alert =
                    new Alert(Alert.AlertType.INFORMATION);

            alert.setTitle("Cliente");

            alert.setHeaderText(null);

            alert.setContentText(
                    "Cliente guardado correctamente"
            );

            alert.showAndWait();
        });

        Button btnSalir = new Button("Salir");

        btnSalir.getStyleClass().add("btn-salir");

        btnSalir.setPrefWidth(100);

        btnSalir.setOnAction(
                e -> parent.getChildren().remove(this)
        );

        hbButtons.getChildren().addAll(
                btnGuardar,
                btnSalir
        );

        this.getChildren().addAll(
                titulo,
                grid,
                hbButtons
        );
    }
}