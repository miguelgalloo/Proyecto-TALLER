package sistemagestionfx;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class FormularioProveedor extends VBox {

    public FormularioProveedor(StackPane parent) {

        this.getStylesheets().add(
                getClass().getResource("style.css").toExternalForm()
        );

        this.getStyleClass().add("form-container");

        this.setSpacing(15);

        this.setPadding(new Insets(30));

        this.setAlignment(Pos.CENTER);

        this.setMaxSize(400, 350);

        Label titulo = new Label("GESTIÓN DE PROVEEDORES");

        titulo.setStyle(
                "-fx-font-size: 20px; -fx-font-weight: bold;"
        );

        GridPane grid = new GridPane();

        grid.setHgap(10);

        grid.setVgap(15);

        grid.setAlignment(Pos.CENTER);

        // NIT
        grid.add(new Label("NIT:"), 0, 0);

        TextField txtNit = new TextField();

        grid.add(txtNit, 1, 0);

        // EMPRESA
        grid.add(new Label("Empresa:"), 0, 1);

        TextField txtEmpresa = new TextField();

        grid.add(txtEmpresa, 1, 1);

        // CORREO
        grid.add(new Label("Correo:"), 0, 2);

        TextField txtCorreo = new TextField();

        grid.add(txtCorreo, 1, 2);

        // BOTONES
        HBox hbButtons = new HBox(15);

        hbButtons.setAlignment(Pos.CENTER);

        Button btnGuardar = new Button("Guardar");

        btnGuardar.getStyleClass().add("btn-entrar");

        btnGuardar.setPrefWidth(100);

        btnGuardar.setOnAction(e -> {

            Alert alert =
                    new Alert(Alert.AlertType.INFORMATION);

            alert.setTitle("Proveedor");

            alert.setHeaderText(null);

            alert.setContentText(
                    "Proveedor guardado correctamente"
            );

            alert.showAndWait();
        });

        Button btnSalir = new Button("Salir");

        btnSalir.getStyleClass().add("btn-salir");

        btnSalir.setPrefWidth(100);

        btnSalir.setOnAction(
                e -> parent.getChildren().remove(this)
        );

        hbButtons.getChildren().addAll(
                btnGuardar,
                btnSalir
        );

        this.getChildren().addAll(
                titulo,
                grid,
                hbButtons
        );
    }
}