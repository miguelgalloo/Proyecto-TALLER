package sistemagestionfx;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class FormularioUsuario extends VBox {

    public FormularioUsuario(StackPane parent) {

       
        this.getStylesheets().add(
                getClass().getResource("style.css").toExternalForm()
        );

        this.getStyleClass().add("form-container");

        this.setSpacing(15);

        this.setPadding(new Insets(30));

        this.setAlignment(Pos.CENTER);

        this.setMaxSize(400, 350);

        
        Label titulo = new Label("ACCESO DE USUARIO");

        titulo.setStyle(
                "-fx-font-size: 20px; -fx-font-weight: bold;"
        );

        
        GridPane grid = new GridPane();

        grid.setHgap(10);

        grid.setVgap(15);

        grid.setAlignment(Pos.CENTER);

        
        grid.add(new Label("NID:"), 0, 0);

        TextField txtNid = new TextField();

        txtNid.setPromptText("Ej: 123456");

        
        txtNid.textProperty().addListener(
                (observable, oldValue, newValue) -> {

                    if (!newValue.matches("\\d*")) {

                        txtNid.setText(
                                newValue.replaceAll("[^\\d]", "")
                        );
                    }
                });

        grid.add(txtNid, 1, 0);

        
        grid.add(new Label("Usuario:"), 0, 1);

        TextField txtNombre = new TextField();

        grid.add(txtNombre, 1, 1);

        
        grid.add(new Label("Clave:"), 0, 2);

        PasswordField txtClave = new PasswordField();

        Label lblErrorClave =
                new Label("Mínimo 4 caracteres");

        lblErrorClave.setStyle(
                "-fx-text-fill: #e74c3c; -fx-font-size: 10px;"
        );

        lblErrorClave.setVisible(false);

        
        txtClave.textProperty().addListener(
                (obs, oldVal, newVal) -> {

                    if (newVal.length() < 4) {

                        lblErrorClave.setVisible(true);

                        txtClave.getStyleClass()
                                .add("error-field");

                    } else {

                        lblErrorClave.setVisible(false);

                        txtClave.getStyleClass()
                                .removeAll("error-field");
                    }
                });

        VBox claveBox =
                new VBox(5, txtClave, lblErrorClave);

        grid.add(claveBox, 1, 2);

        
        HBox hbButtons = new HBox(15);

        hbButtons.setAlignment(Pos.CENTER);

        
        Button btnEntrar = new Button("Entrar");

        btnEntrar.getStyleClass().add("btn-entrar");

        btnEntrar.setPrefWidth(100);

        btnEntrar.setOnAction(e -> {

            if (txtNid.getText().isEmpty()
                    || txtClave.getText().length() < 4) {

                Alert alert =
                        new Alert(Alert.AlertType.WARNING);

                alert.setTitle("Validación");

                alert.setHeaderText(null);

                alert.setContentText(
                        "Por favor, revise los campos marcados."
                );

                alert.showAndWait();

            } else {

                Alert alert =
                        new Alert(Alert.AlertType.INFORMATION);

                alert.setTitle("Correcto");

                alert.setHeaderText(null);

                alert.setContentText(
                        "Ingreso exitoso para: "
                        + txtNombre.getText()
                );

                alert.showAndWait();
            }
        });

        
        Button btnSalir = new Button("Salir");

        btnSalir.getStyleClass().add("btn-salir");

        btnSalir.setPrefWidth(100);

        btnSalir.setOnAction(
                e -> parent.getChildren().remove(this)
        );

        hbButtons.getChildren().addAll(
                btnEntrar,
                btnSalir
        );

        
        this.getChildren().addAll(
                titulo,
                grid,
                hbButtons
        );
    }
}