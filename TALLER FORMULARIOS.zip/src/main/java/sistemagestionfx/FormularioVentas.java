package sistemagestionfx;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class FormularioVentas extends VBox {

    public FormularioVentas(StackPane parent) {

        this.getStylesheets().add(
                getClass().getResource("style.css").toExternalForm()
        );

        this.getStyleClass().add("form-container");

        this.setSpacing(15);

        this.setPadding(new Insets(30));

        this.setAlignment(Pos.CENTER);

        this.setMaxSize(400, 350);

        Label titulo = new Label("GESTIÓN DE VENTAS");

        titulo.setStyle(
                "-fx-font-size: 20px; -fx-font-weight: bold;"
        );

        GridPane grid = new GridPane();

        grid.setHgap(10);

        grid.setVgap(15);

        grid.setAlignment(Pos.CENTER);

        // CODIGO
        grid.add(new Label("Código Venta:"), 0, 0);

        TextField txtCodigo = new TextField();

        grid.add(txtCodigo, 1, 0);

        // PRODUCTO
        grid.add(new Label("Producto:"), 0, 1);

        TextField txtProducto = new TextField();

        grid.add(txtProducto, 1, 1);

        // VALOR
        grid.add(new Label("Valor:"), 0, 2);

        TextField txtValor = new TextField();

        grid.add(txtValor, 1, 2);

        // BOTONES
        HBox hbButtons = new HBox(15);

        hbButtons.setAlignment(Pos.CENTER);

        Button btnGuardar = new Button("Guardar");

        btnGuardar.getStyleClass().add("btn-entrar");

        btnGuardar.setPrefWidth(100);

        btnGuardar.setOnAction(e -> {

            Alert alert =
                    new Alert(Alert.AlertType.INFORMATION);

            alert.setTitle("Ventas");

            alert.setHeaderText(null);

            alert.setContentText(
                    "Venta registrada correctamente"
            );

            alert.showAndWait();
        });

        Button btnSalir = new Button("Salir");

        btnSalir.getStyleClass().add("btn-salir");

        btnSalir.setPrefWidth(100);

        btnSalir.setOnAction(
                e -> parent.getChildren().remove(this)
        );

        hbButtons.getChildren().addAll(
                btnGuardar,
                btnSalir
        );

        this.getChildren().addAll(
                titulo,
                grid,
                hbButtons
        );
    }
}