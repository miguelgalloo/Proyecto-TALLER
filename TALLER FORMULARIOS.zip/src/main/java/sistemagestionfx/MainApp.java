package sistemagestionfx;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class MainApp extends Application {

    private StackPane workspace;

    @Override
    public void start(Stage primaryStage) {

        BorderPane root = new BorderPane();

        workspace = new StackPane();

        workspace.setStyle("-fx-background-color: #f4f4f4;");

        // ===== MENU BAR =====

        MenuBar menuBar = new MenuBar();

        // ===== USUARIO =====

        Menu menuUsuario = new Menu("Usuario");

        MenuItem itemUsuario =
                new MenuItem("Gestionar Usuario");

        itemUsuario.setOnAction(
                e -> abrirFormularioUsuario()
        );

        menuUsuario.getItems().add(itemUsuario);

        // ===== CLIENTE =====

        Menu menuCliente = new Menu("Cliente");

        MenuItem itemCliente =
                new MenuItem("Gestionar Cliente");

        itemCliente.setOnAction(
                e -> abrirFormularioCliente()
        );

        menuCliente.getItems().add(itemCliente);

        // ===== PROVEEDOR =====

        Menu menuProveedor = new Menu("Proveedor");

        MenuItem itemProveedor =
                new MenuItem("Gestionar Proveedor");

        itemProveedor.setOnAction(
                e -> abrirFormularioProveedor()
        );

        menuProveedor.getItems().add(itemProveedor);

        // ===== VENTAS =====

        Menu menuVentas = new Menu("Ventas");

        MenuItem itemVentas =
                new MenuItem("Gestionar Ventas");

        itemVentas.setOnAction(
                e -> abrirFormularioVentas()
        );

        menuVentas.getItems().add(itemVentas);

        // ===== SALIR =====

        Menu menuSalir = new Menu("Salir");

        MenuItem itemSalir =
                new MenuItem("Cerrar Aplicación");

        itemSalir.setOnAction(
                e -> System.exit(0)
        );

        menuSalir.getItems().add(itemSalir);

        // ===== AGREGAR MENUS =====

        menuBar.getMenus().addAll(
                menuUsuario,
                menuCliente,
                menuProveedor,
                menuVentas,
                menuSalir
        );

        root.setTop(menuBar);

        root.setCenter(workspace);

        Scene scene = new Scene(root, 1000, 700);

        primaryStage.setTitle(
                "Sistema de Gestión - Panel Principal"
        );

        primaryStage.setScene(scene);

        primaryStage.show();
    }

    // ===== FORMULARIO USUARIO =====

    private void abrirFormularioUsuario() {

        workspace.getChildren().clear();

        FormularioUsuario form =
                new FormularioUsuario(workspace);

        workspace.getChildren().add(form);
    }

    // ===== FORMULARIO CLIENTE =====

    private void abrirFormularioCliente() {

        workspace.getChildren().clear();

        FormularioCliente form =
                new FormularioCliente(workspace);

        workspace.getChildren().add(form);
    }

    // ===== FORMULARIO PROVEEDOR =====

    private void abrirFormularioProveedor() {

        workspace.getChildren().clear();

        FormularioProveedor form =
                new FormularioProveedor(workspace);

        workspace.getChildren().add(form);
    }

    // ===== FORMULARIO VENTAS =====

    private void abrirFormularioVentas() {

        workspace.getChildren().clear();

        FormularioVentas form =
                new FormularioVentas(workspace);

        workspace.getChildren().add(form);
    }

    public static void main(String[] args) {

        launch(args);
    }
}